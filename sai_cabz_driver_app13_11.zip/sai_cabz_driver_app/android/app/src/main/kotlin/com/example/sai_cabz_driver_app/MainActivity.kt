package com.example.sai_cabz_driver_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
